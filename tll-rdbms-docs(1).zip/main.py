# main.py - Entry point for TLL Framework
import yaml
import argparse

def load_config(path):
    with open(path, 'r') as file:
        return yaml.safe_load(file)

def main(config_path):
    config = load_config(config_path)
    print("Loaded configuration:")
    print(config)
    # Here you would initialize TLL loops, models, and data pipeline

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run TLL Framework")
    parser.add_argument('--config', type=str, default='configs/tll_default.yaml')
    args = parser.parse_args()
    main(args.config)
